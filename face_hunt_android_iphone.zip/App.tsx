import React, { useEffect, useMemo, useState } from "react";
import {
  Dimensions,
  Image,
  Pressable,
  SafeAreaView,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from "react-native";
import { LinearGradient } from "expo-linear-gradient";
import * as Haptics from "expo-haptics";
import { StatusBar } from "expo-status-bar";

type Difficulty = "easy" | "normal" | "hard";
type Screen = "home" | "memory" | "hunt" | "result";

type Person = {
  id: number;
  name: string;
  image: string;
};

type Modification = {
  glasses?: boolean;
  moustache?: boolean;
  hair?: boolean;
};

const PEOPLE: Person[] = [
  { id: 1, name: "Alex", image: "https://randomuser.me/api/portraits/men/32.jpg" },
  { id: 2, name: "Maya", image: "https://randomuser.me/api/portraits/women/44.jpg" },
  { id: 3, name: "Noah", image: "https://randomuser.me/api/portraits/men/46.jpg" },
  { id: 4, name: "Emma", image: "https://randomuser.me/api/portraits/women/65.jpg" },
  { id: 5, name: "Leo", image: "https://randomuser.me/api/portraits/men/75.jpg" },
  { id: 6, name: "Sofia", image: "https://randomuser.me/api/portraits/women/68.jpg" },
  { id: 7, name: "Ethan", image: "https://randomuser.me/api/portraits/men/22.jpg" },
  { id: 8, name: "Olivia", image: "https://randomuser.me/api/portraits/women/32.jpg" },
  { id: 9, name: "Daniel", image: "https://randomuser.me/api/portraits/men/11.jpg" },
  { id: 10, name: "Ava", image: "https://randomuser.me/api/portraits/women/12.jpg" },
  { id: 11, name: "Max", image: "https://randomuser.me/api/portraits/men/52.jpg" },
  { id: 12, name: "Luna", image: "https://randomuser.me/api/portraits/women/21.jpg" },
];

const DIFFICULTY = {
  easy: { label: "Легко", seconds: 5, count: 6 },
  normal: { label: "Нормально", seconds: 4, count: 9 },
  hard: { label: "Сложно", seconds: 3, count: 12 },
};

function shuffle<T>(arr: T[]): T[] {
  return [...arr].sort(() => Math.random() - 0.5);
}

function randomModification(): Modification {
  const mods: Modification[] = [
    { glasses: true },
    { moustache: true },
    { hair: true },
    { glasses: true, moustache: true },
    { glasses: true, hair: true },
    { moustache: true, hair: true },
  ];
  return mods[Math.floor(Math.random() * mods.length)];
}

function FaceCard({
  person,
  modification,
  selected,
  onPress,
}: {
  person: Person;
  modification?: Modification;
  selected?: boolean;
  onPress: () => void;
}) {
  return (
    <Pressable
      onPress={onPress}
      style={[styles.faceCard, selected && styles.faceCardSelected]}
    >
      <Image source={{ uri: person.image }} style={styles.faceImage} />
      {modification?.hair && <View style={styles.hairOverlay}><Text>〰</Text></View>}
      {modification?.glasses && <Text style={styles.glasses}>👓</Text>}
      {modification?.moustache && <Text style={styles.moustache}>🥸</Text>}
      <LinearGradient
        colors={["transparent", "rgba(0,0,0,.72)"]}
        style={styles.cardShade}
      />
      <Text style={styles.faceName}>{person.name}</Text>
    </Pressable>
  );
}

export default function App() {
  const [screen, setScreen] = useState<Screen>("home");
  const [difficulty, setDifficulty] = useState<Difficulty>("normal");
  const [round, setRound] = useState(1);
  const [score, setScore] = useState(0);
  const [streak, setStreak] = useState(0);
  const [lives, setLives] = useState(3);
  const [target, setTarget] = useState<Person>(PEOPLE[0]);
  const [options, setOptions] = useState<Person[]>([]);
  const [modification, setModification] = useState<Modification>({});
  const [seconds, setSeconds] = useState(4);
  const [resultText, setResultText] = useState("");
  const [locked, setLocked] = useState(false);

  const cfg = DIFFICULTY[difficulty];

  const startGame = () => {
    const chosen = shuffle(PEOPLE);
    setRound(1);
    setScore(0);
    setStreak(0);
    setLives(3);
    setTarget(chosen[0]);
    setModification(randomModification());
    setOptions([]);
    setResultText("");
    setSeconds(cfg.seconds);
    setScreen("memory");
  };

  const buildRound = () => {
    const others = shuffle(PEOPLE.filter((p) => p.id !== target.id)).slice(
      0,
      cfg.count - 1
    );
    setOptions(shuffle([target, ...others]));
    setModification(randomModification());
    setLocked(false);
    setResultText("");
    setScreen("hunt");
  };

  useEffect(() => {
    if (screen !== "memory") return;
    if (seconds <= 0) {
      buildRound();
      return;
    }
    const timer = setTimeout(() => setSeconds((s) => s - 1), 1000);
    return () => clearTimeout(timer);
  }, [screen, seconds]);

  const choose = async (person: Person) => {
    if (locked) return;
    setLocked(true);

    const correct = person.id === target.id;
    if (correct) {
      await Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      const newStreak = streak + 1;
      setStreak(newStreak);
      setScore((s) => s + 100 + newStreak * 25);
      setResultText("ПРАВИЛЬНО!");
    } else {
      await Haptics.notificationAsync(Haptics.NotificationFeedbackType.Error);
      setStreak(0);
      const newLives = lives - 1;
      setLives(newLives);
      setResultText("НЕПРАВИЛЬНО");
      if (newLives <= 0) {
        setTimeout(() => setScreen("result"), 650);
        return;
      }
    }

    setTimeout(() => {
      const nextTarget = shuffle(PEOPLE)[0];
      setTarget(nextTarget);
      setRound((r) => r + 1);
      setSeconds(cfg.seconds);
      setModification(randomModification());
      setScreen("memory");
    }, 650);
  };

  const title = useMemo(() => {
    if (screen === "home") return "FACE HUNT";
    if (screen === "memory") return "ЗАПОМНИ ЛИЦО";
    if (screen === "hunt") return "НАЙДИ ЕГО";
    return "ИГРА ОКОНЧЕНА";
  }, [screen]);

  return (
    <LinearGradient colors={["#08080B", "#14131A", "#08080B"]} style={styles.root}>
      <StatusBar style="light" />
      <SafeAreaView style={styles.safe}>
        <View style={styles.header}>
          <Text style={styles.logo}>{title}</Text>
          {screen !== "home" && screen !== "result" && (
            <View style={styles.stats}>
              <Text style={styles.stat}>❤️ {lives}</Text>
              <Text style={styles.stat}>⭐ {score}</Text>
            </View>
          )}
        </View>

        {screen === "home" && (
          <ScrollView contentContainerStyle={styles.home}>
            <View style={styles.hero}>
              <Text style={styles.emoji}>👁️</Text>
              <Text style={styles.heroTitle}>Сможешь узнать лицо?</Text>
              <Text style={styles.heroText}>
                Запомни человека. Затем найди его среди других фотографий —
                даже когда его черты изменились.
              </Text>
            </View>

            <Text style={styles.sectionTitle}>Сложность</Text>
            <View style={styles.difficultyRow}>
              {(Object.keys(DIFFICULTY) as Difficulty[]).map((d) => (
                <Pressable
                  key={d}
                  onPress={() => setDifficulty(d)}
                  style={[
                    styles.difficulty,
                    difficulty === d && styles.difficultyActive,
                  ]}
                >
                  <Text style={styles.difficultyTitle}>{DIFFICULTY[d].label}</Text>
                  <Text style={styles.difficultySub}>
                    {DIFFICULTY[d].seconds} сек.
                  </Text>
                </Pressable>
              ))}
            </View>

            <Pressable onPress={startGame} style={styles.mainButton}>
              <Text style={styles.mainButtonText}>ИГРАТЬ</Text>
            </Pressable>

            <Text style={styles.note}>
              В демо используются публичные портреты. Для релиза их можно
              заменить на собственный лицензированный набор.
            </Text>
          </ScrollView>
        )}

        {screen === "memory" && (
          <View style={styles.gameScreen}>
            <Text style={styles.round}>РАУНД {round}</Text>
            <Text style={styles.instruction}>Запомни этого человека</Text>
            <View style={styles.bigFaceWrap}>
              <Image source={{ uri: target.image }} style={styles.bigFace} />
              {modification.glasses && <Text style={styles.bigGlasses}>👓</Text>}
              {modification.moustache && <Text style={styles.bigMoustache}>🥸</Text>}
              {modification.hair && <View style={styles.bigHair}><Text>〰</Text></View>}
              <LinearGradient
                colors={["transparent", "rgba(0,0,0,.65)"]}
                style={styles.bigShade}
              />
              <Text style={styles.bigName}>{target.name}</Text>
            </View>
            <View style={styles.timerCircle}>
              <Text style={styles.timerText}>{seconds}</Text>
            </View>
            <Text style={styles.hint}>После этого лицо изменится.</Text>
          </View>
        )}

        {screen === "hunt" && (
          <View style={styles.gameScreen}>
            <Text style={styles.instruction}>Кто был на предыдущем фото?</Text>
            <Text style={styles.hint}>Найди человека среди {options.length} вариантов</Text>
            <View style={styles.grid}>
              {options.map((p) => (
                <FaceCard
                  key={p.id}
                  person={p}
                  modification={p.id === target.id ? modification : undefined}
                  selected={locked && p.id === target.id}
                  onPress={() => choose(p)}
                />
              ))}
            </View>
            <Text style={styles.result}>{resultText}</Text>
          </View>
        )}

        {screen === "result" && (
          <View style={styles.gameScreen}>
            <Text style={styles.resultEmoji}>🏆</Text>
            <Text style={styles.heroTitle}>Результат</Text>
            <Text style={styles.finalScore}>{score}</Text>
            <Text style={styles.hint}>очков</Text>
            <View style={styles.resultBox}>
              <Text style={styles.resultLine}>Раундов: {round}</Text>
              <Text style={styles.resultLine}>Лучшая серия: {streak}</Text>
              <Text style={styles.resultLine}>Сложность: {cfg.label}</Text>
            </View>
            <Pressable onPress={startGame} style={styles.mainButton}>
              <Text style={styles.mainButtonText}>ИГРАТЬ СНОВА</Text>
            </Pressable>
            <Pressable onPress={() => setScreen("home")} style={styles.secondaryButton}>
              <Text style={styles.secondaryText}>В МЕНЮ</Text>
            </Pressable>
          </View>
        )}
      </SafeAreaView>
    </LinearGradient>
  );
}

const { width } = Dimensions.get("window");
const gap = 10;
const gridColumns = 3;
const cardWidth = (width - 40 - gap * 2) / gridColumns;

const styles = StyleSheet.create({
  root: { flex: 1 },
  safe: { flex: 1, paddingHorizontal: 20 },
  header: {
    minHeight: 58,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
  },
  logo: { color: "#fff", fontSize: 17, fontWeight: "900", letterSpacing: 2 },
  stats: { flexDirection: "row", gap: 12 },
  stat: { color: "#fff", fontWeight: "800" },
  home: { paddingTop: 26, paddingBottom: 40 },
  hero: { alignItems: "center", paddingVertical: 22 },
  emoji: { fontSize: 64, marginBottom: 16 },
  heroTitle: { color: "#fff", fontSize: 29, fontWeight: "900", textAlign: "center" },
  heroText: {
    color: "#A7A7B0",
    fontSize: 16,
    lineHeight: 24,
    textAlign: "center",
    marginTop: 12,
    maxWidth: 430,
  },
  sectionTitle: { color: "#fff", fontSize: 16, fontWeight: "800", marginTop: 28, marginBottom: 12 },
  difficultyRow: { flexDirection: "row", gap: 9 },
  difficulty: {
    flex: 1,
    borderRadius: 16,
    paddingVertical: 14,
    alignItems: "center",
    backgroundColor: "rgba(255,255,255,.07)",
    borderWidth: 1,
    borderColor: "rgba(255,255,255,.09)",
  },
  difficultyActive: { backgroundColor: "#FFFFFF", borderColor: "#fff" },
  difficultyTitle: { color: "#fff", fontWeight: "900" },
  difficultySub: { color: "#9999A4", fontSize: 12, marginTop: 4 },
  mainButton: {
    marginTop: 24,
    backgroundColor: "#fff",
    borderRadius: 17,
    paddingVertical: 17,
    alignItems: "center",
  },
  mainButtonText: { color: "#09090B", fontWeight: "900", fontSize: 16, letterSpacing: 1 },
  secondaryButton: {
    marginTop: 12,
    borderRadius: 17,
    paddingVertical: 16,
    alignItems: "center",
    borderWidth: 1,
    borderColor: "rgba(255,255,255,.15)",
  },
  secondaryText: { color: "#fff", fontWeight: "800" },
  note: { color: "#6F6F79", fontSize: 12, textAlign: "center", marginTop: 18, lineHeight: 18 },
  gameScreen: { flex: 1, alignItems: "center", paddingTop: 12 },
  round: { color: "#777782", fontSize: 12, fontWeight: "900", letterSpacing: 2 },
  instruction: { color: "#fff", fontSize: 22, fontWeight: "900", textAlign: "center", marginTop: 8 },
  hint: { color: "#888893", fontSize: 13, textAlign: "center", marginTop: 8 },
  bigFaceWrap: {
    width: Math.min(width - 44, 390),
    aspectRatio: 0.78,
    borderRadius: 28,
    overflow: "hidden",
    marginTop: 20,
    position: "relative",
    backgroundColor: "#222",
  },
  bigFace: { width: "100%", height: "100%" },
  bigShade: { ...StyleSheet.absoluteFillObject, top: "55%" },
  bigName: { position: "absolute", bottom: 18, left: 20, color: "#fff", fontSize: 23, fontWeight: "900" },
  timerCircle: {
    width: 54, height: 54, borderRadius: 27,
    backgroundColor: "#fff", alignItems: "center", justifyContent: "center",
    marginTop: 16,
  },
  timerText: { color: "#09090B", fontSize: 22, fontWeight: "900" },
  grid: { width: "100%", flexDirection: "row", flexWrap: "wrap", gap, marginTop: 18, justifyContent: "center" },
  faceCard: {
    width: cardWidth, aspectRatio: 0.82, borderRadius: 15, overflow: "hidden",
    backgroundColor: "#222", position: "relative",
  },
  faceCardSelected: { borderWidth: 3, borderColor: "#fff" },
  faceImage: { width: "100%", height: "100%" },
  cardShade: { position: "absolute", left: 0, right: 0, bottom: 0, height: "50%" },
  faceName: { position: "absolute", left: 9, bottom: 8, color: "#fff", fontSize: 12, fontWeight: "800" },
  glasses: { position: "absolute", top: "36%", alignSelf: "center", fontSize: 29, zIndex: 2 },
  moustache: { position: "absolute", top: "51%", alignSelf: "center", fontSize: 26, zIndex: 2 },
  hairOverlay: { position: "absolute", top: 5, left: "30%", zIndex: 2, backgroundColor: "#111", borderRadius: 30, paddingHorizontal: 12 },
  bigGlasses: { position: "absolute", top: "39%", alignSelf: "center", fontSize: 55, zIndex: 2 },
  bigMoustache: { position: "absolute", top: "52%", alignSelf: "center", fontSize: 48, zIndex: 2 },
  bigHair: { position: "absolute", top: 8, left: "38%", zIndex: 2, backgroundColor: "#111", borderRadius: 40, paddingHorizontal: 24, paddingVertical: 8 },
  result: { color: "#fff", fontSize: 18, fontWeight: "900", marginTop: 12, minHeight: 24 },
  resultEmoji: { fontSize: 72, marginTop: 50 },
  finalScore: { color: "#fff", fontSize: 64, fontWeight: "900", marginTop: 10 },
  resultBox: { marginTop: 25, width: "100%", padding: 20, borderRadius: 18, backgroundColor: "rgba(255,255,255,.06)" },
  resultLine: { color: "#ddd", fontSize: 16, fontWeight: "700", textAlign: "center", marginVertical: 5 },
});
